// localStorage를 사용한 클라이언트 사이드 데이터 관리
export const storage = {
  // 사용자 데이터
  getUser: () => {
    if (typeof window === "undefined") return null
    const data = localStorage.getItem("user")
    return data ? JSON.parse(data) : null
  },

  setUser: (user: any) => {
    if (typeof window === "undefined") return
    localStorage.setItem("user", JSON.stringify(user))
  },

  // 학습 진도
  getProgress: () => {
    if (typeof window === "undefined") return null
    const data = localStorage.getItem("progress")
    return data
      ? JSON.parse(data)
      : {
          level: 1,
          currentChapter: 1,
          completedChapters: [],
          quizScores: {},
          exp: 0,
          totalExp: 1000,
        }
  },

  setProgress: (progress: any) => {
    if (typeof window === "undefined") return
    localStorage.setItem("progress", JSON.stringify(progress))
  },

  // 포트폴리오
  getPortfolio: () => {
    if (typeof window === "undefined") return null
    const data = localStorage.getItem("portfolio")
    return data
      ? JSON.parse(data)
      : {
          cash: 10000000,
          totalAssets: 10000000,
          stocks: [],
          profitRate: 0,
        }
  },

  setPortfolio: (portfolio: any) => {
    if (typeof window === "undefined") return
    localStorage.setItem("portfolio", JSON.stringify(portfolio))
  },

  // 게임 진행
  getGameProgress: () => {
    if (typeof window === "undefined") return null
    const data = localStorage.getItem("gameProgress")
    return data
      ? JSON.parse(data)
      : {
          currentWeek: 1,
          currentDay: 1,
          completedWeeks: [],
        }
  },

  setGameProgress: (gameProgress: any) => {
    if (typeof window === "undefined") return
    localStorage.setItem("gameProgress", JSON.stringify(gameProgress))
  },

  // onboarding status management
  getOnboardingStatus: () => {
    if (typeof window === "undefined") return false
    const status = localStorage.getItem("onboardingComplete")
    return status === "true"
  },

  setOnboardingComplete: () => {
    if (typeof window === "undefined") return
    localStorage.setItem("onboardingComplete", "true")
  },

  // user profile management for analysis results
  getUserProfile: () => {
    if (typeof window === "undefined") return null
    const data = localStorage.getItem("userProfile")
    return data ? JSON.parse(data) : null
  },

  saveUserProfile: (profile: any) => {
    if (typeof window === "undefined") return
    localStorage.setItem("userProfile", JSON.stringify(profile))
  },

  // guide completion tracking
  getGuideComplete: () => {
    if (typeof window === "undefined") return false
    const status = localStorage.getItem("guideComplete")
    return status === "true"
  },

  setGuideComplete: () => {
    if (typeof window === "undefined") return
    localStorage.setItem("guideComplete", "true")
  },

  // AI competitors management
  getAICompetitors: () => {
    if (typeof window === "undefined") return null
    const data = localStorage.getItem("aiCompetitors")
    return data ? JSON.parse(data) : null
  },

  updateAICompetitors: (competitors: any) => {
    if (typeof window === "undefined") return
    localStorage.setItem("aiCompetitors", JSON.stringify(competitors))
  },

  // inventory management
  getInventory: () => {
    if (typeof window === "undefined") return []
    const data = localStorage.getItem("inventory")
    return data
      ? JSON.parse(data)
      : [
          { itemId: "insider_tip", count: 1 },
          { itemId: "risk_shield", count: 1 },
        ]
  },

  useItem: (itemId: string) => {
    if (typeof window === "undefined") return false
    const inventory = storage.getInventory()
    const itemIndex = inventory.findIndex((i: any) => i.itemId === itemId)

    if (itemIndex > -1 && inventory[itemIndex].count > 0) {
      inventory[itemIndex].count--
      if (inventory[itemIndex].count === 0) {
        inventory.splice(itemIndex, 1)
      }
      localStorage.setItem("inventory", JSON.stringify(inventory))
      return true
    }
    return false
  },

  // character data management
  getCharacter: () => {
    if (typeof window === "undefined") return null
    const data = localStorage.getItem("character")
    return data ? JSON.parse(data) : null
  },

  setCharacter: (character: any) => {
    if (typeof window === "undefined") return
    localStorage.setItem("character", JSON.stringify(character))
  },

  addExp: (amount: number) => {
    if (typeof window === "undefined") return
    const character = storage.getCharacter()
    if (!character) return

    character.exp = (character.exp || 0) + amount
    character.totalExp = (character.totalExp || 0) + amount

    // Level up logic
    const levels = [0, 1000, 2500, 5000, 10000, 20000]
    for (let i = levels.length - 1; i >= 0; i--) {
      if (character.totalExp >= levels[i]) {
        character.level = i + 1
        break
      }
    }

    storage.setCharacter(character)
  },

  unlockAchievement: (achievementId: string) => {
    if (typeof window === "undefined") return
    const character = storage.getCharacter()
    if (!character) return

    if (!character.achievements) character.achievements = []
    if (!character.achievements.includes(achievementId)) {
      character.achievements.push(achievementId)
      storage.setCharacter(character)
      return true
    }
    return false
  },

  // game settings management
  getGameSettings: () => {
    if (typeof window === "undefined") return null
    const data = localStorage.getItem("gameSettings")
    return data
      ? JSON.parse(data)
      : {
          duration: 3, // Changed default duration to 3 months
          initialCash: 5000000, // 5 million
        }
  },

  setGameSettings: (settings: any) => {
    if (typeof window === "undefined") return
    localStorage.setItem("gameSettings", JSON.stringify(settings))
  },

  // game session management for specific scenarios
  getGameSession: (scenarioId: string) => {
    if (typeof window === "undefined") return null
    const data = localStorage.getItem(`gameSession_${scenarioId}`)
    return data ? JSON.parse(data) : null
  },

  setGameSession: (scenarioId: string, session: any) => {
    if (typeof window === "undefined") return
    localStorage.setItem(`gameSession_${scenarioId}`, JSON.stringify(session))
  },
}
